import Bullet from '../assets/bottomTabNavigation/wallet/bulletPoint.svg';

export const cardFunctionsData: any = [
  {
    heading: 'Online transactions:',
    bodyText:
      'Internet-based transactions are generally high-risk. You can switch them off for extra security',
    svg: Bullet,
    button: 'Toggle',
  },
  {
    heading: 'Location-based security',
    bodyText:
      'We’ll use your location to help prevent fraudulent transactions if your card is ever compromised. GPS must be turned on.',
    svg: Bullet,
    button: 'Toggle',
  },
  {
    heading: 'Swipe payments',
    bodyText:
      'Sometimes cards can be cloned. Switch off the magnetic stripe for extra security.',
    svg: Bullet,
    button: 'Toggle',
  },
  {
    heading: 'ATM withdrawals',
    bodyText:
      'If you do not plan to withdraw cash, you can swtich ATM withdrawals off.',
    svg: Bullet,
    button: 'Toggle',
  },
  {
    heading: 'Contacless payments',
    bodyText:
      'You can disable contacless payments by turning this setting off. Payemnts you make using mobile wallets like Apple Pay won’t be affected.',
    svg: Bullet,
    button: 'Toggle',
  },
  {
    heading: 'Contacless payments',
    bodyText: '€- / €200',
    svg: Bullet,
    button: 'Reset',
  },
  {
    heading: 'Terminate card',
    bodyText: 'This card will be permanently terminated',
    svg: Bullet,
    button: 'Terminate',
  },
];

export const dummyHorizontalData = [
  'Futures',
  'Spot',
  'Tokenized Stocks',
  'Leveraged Tokens',
  'Volatility',
  'Prediction',
  'Fiat',
];

export const dummyCurrencyData = ['USD', 'USDT', 'BTC', 'EUR'];

export const filterButtons = [
  {
    name: 'USD',
    id: 'USD',
  },
  {
    name: 'EUR',
    id: 'EUR',
  },
  {
    name: 'USDT',
    id: 'USDT',
  },
  {
    name: 'BTC',
    id: 'BTC',
  },
];

export const dropDownArray = [
  'Hip Hop',
  'R&B/ Soul',
  'Electronic',
  'Pop',
  'Rock',
  'Reggae/Dancehall',
  'Reggaeton',
  'Afro',
];

export const sideTypeDropDowndata = [
  {label: 'Buy', value: 'side'},
  {label: 'Sell', value: 'side'},
];

export const orderTypeDropDowndata = [
  {label: 'Limit Order', value: 'orderType'},
  {label: 'Market Order', value: 'orderType'},
  {label: 'Stop Market', value: 'orderType'},
  {label: 'Stop Limit', value: 'orderType'},
  {label: 'Trailing Stop', value: 'orderType'},
  {label: 'Take Profit', value: 'orderType'},
  {label: 'Take Profit Limit', value: 'orderType'},
];

export const orderBookTabsData = [
  'Balances',
  'Open Orders',
  'Active TWAP Orders',
  'Triger Orders',
  'Borrowed Spot Positions',
  'Order History',
  'Trade History',
];
