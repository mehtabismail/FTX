import {StyleSheet, Text, View} from 'react-native';
import React from 'react';
import metrics from '../../theme/Metrics';
import Colors from '../../theme/Colors';
import SpendingFilter from './SpendingFilter';
import Accounts from '../../assets/bottomTabNavigation/wallet/accounts.svg';
import Calender from '../../assets/bottomTabNavigation/wallet/calendar.svg';
import CustomCard from '../../components/CustomCard';
import CustomGraphCard from '../../components/CustomGraphCard';

const data: any = [
  {body: 'All accounts', svg: Accounts},
  {body: 'This month', svg: Calender},
];

const Spending = () => {
  return (
    <View>
      <View style={styles.mainContainer}>
        <View>
          <Text style={styles.headingTextStyle}>Spending</Text>
        </View>
        <View style={styles.filter}>
          {data.map((items: any, index: any) => {
            return (
              <View key={index}>
                <SpendingFilter body={items.body} svg={items.svg} />
              </View>
            );
          })}
        </View>
      </View>
      <View>
        <CustomGraphCard amount="1,410.51" profitLoss="+396" />
      </View>
    </View>
  );
};

export default Spending;

const styles = StyleSheet.create({
  mainContainer: {
    marginLeft: metrics.separaterMargin,
    marginTop: metrics.doubleBaseMargin,
    marginBottom: metrics.baseMargin,
  },
  headingTextStyle: {
    color: Colors.textColor,
    fontSize: 24,
    fontStyle: 'normal',
    fontFamily: 'RedHatDisplay-Bold',
  },
  filter: {
    marginTop: metrics.baseMargin,
    flexDirection: 'row',
  },
});
