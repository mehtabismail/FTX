import * as React from 'react';
import {View, TouchableOpacity, StyleSheet, Dimensions} from 'react-native';
import {Modal, Portal, Text, Provider} from 'react-native-paper';
import Colors from '../../../theme/Colors';

const MarkeetingModal = ({
  visible,
  HandleVisibility,
  setOrderType,
  ModalHandler,
}: any) => {
  const hideModal = () => HandleVisibility(false);
  const containerStyle = {
    backgroundColor: Colors.background,
    padding: 20,
  };
  let markeetingBtnText = [
    'Limit Order',
    'Market Order',
    'Stop Market',
    'Stop Limit',
    'Trailing Stop',
    'Take Profit',
    'Take Profit Limit',
  ];

  return (
    <Provider>
      <Portal>
        <Modal
          style={{
            paddingHorizontal: 20,
          }}
          visible={visible}
          onDismiss={hideModal}
          contentContainerStyle={[containerStyle]}>
          {markeetingBtnText.map(text => {
            return (
              <TouchableOpacity
                onPress={() => {
                  console.log(text, 'textOrderatype');
                  ModalHandler(text);
                  HandleVisibility(false);
                }}>
                <Text style={{paddingVertical: 20}}>{text}</Text>
              </TouchableOpacity>
            );
          })}
        </Modal>
      </Portal>
    </Provider>
  );
};

const styles = StyleSheet.create({});

export default MarkeetingModal;
