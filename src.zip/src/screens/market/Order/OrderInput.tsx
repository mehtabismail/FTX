import {StyleSheet, Text, TextInput, View} from 'react-native';
import React from 'react';
import Colors from '../../../theme/Colors';

const OrderInput = (props: any) => {
  // console.log(props)
  return (
    <View style={{paddingVertical: 15}}>
      <Text
        numberOfLines={1}
        style={{
          color: Colors.black,
          fontFamily: 'RedHatDisplay-SemiBold',
          fontSize: 13,
        }}>
        {props?.inputHeading}
      </Text>

      <View
        style={{
          borderBottomWidth: 1,
          borderColor: 'gray',
          display: 'flex',
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}>
        <TextInput
          style={{
            height: 40,
            width: '100%',
          }}
          onChangeText={e =>
            props?.textInputHandler(e, props.inputHeading, props?.orderType)
          }
          editable={
            props.editable === false && props.orderType === 'Market Order' ? false : true
          }
          value={
            props?.value
            // props?.placeholder && props?.placeholder
            //   ? props?.placeholder
            //   : props?.orderType && props?.orderType === 'Market Order'
            //   ? 'Market '
            //   : props?.orderType === 'Trailing Stop'
            //   ? '0'
            //   : props?.orderData?.price && props?.orderData?.price
          }
          placeholderTextColor={Colors.black}
        />
        {!props?.flag ? <Text style={{color: Colors.Gray_4}}>USD</Text> : null}
      </View>
    </View>
  );
};

export default OrderInput;

const styles = StyleSheet.create({});
