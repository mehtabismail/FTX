import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const CreateSellOrder = () => {
  return (
    <View>
      <Text>createSellOrder</Text>
    </View>
  )
{/* <View>
<OrderTypeForm
  Btntext={Btntext}
  HandleVisibility={HandleVisibility}
  orderType={orderType}
  
/>
<View>
  {status === 'initial' ? (
    <WarningMsg />
  ) : (
    <View>
      <CheckBox
        checked={checked}
        setChecked={setChecked}
        labelTxt="Post only"
      />
      <CheckBox
        checked={checked}
        setChecked={setChecked}
        labelTxt="IOC"
      />
    </View>
  )}
</View>
</View> */}
  
}

export default CreateSellOrder

const styles = StyleSheet.create({})