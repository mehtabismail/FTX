import {
  Dimensions,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import React, {useState} from 'react';
import BankingHeader from './bankingHeader';
import BankingTabs from './bankingTabs';
import {mainStyle, Shadow} from '../../components/styles/ScreenStyle';
import Colors from '../../theme/Colors';
import SwitchableComponent from '../../components/SwitchableComponent';
import Individuals from './individuals';
import CurrencyModal from './CurrencyModal';
import BackBtnHeader from '../../components/BackBtnHeader';
import CustomTextInput from '../../components/CustomTextInput';
import CustomButton from '../../components/CustomButton';
import {configData} from '../../config/config';

const BankTransfer = () => {
  const {corporate_token, server_url, api_key} = configData;
  const [selected, setSelected] = React.useState(0);
  const [visible, setVisible] = useState(false);
  const [currencyType, setCurrencyType] = useState('Currency');
  const [pressed, setPressed] = useState(false);

  const [formData, setFormData] = useState({
    amount: '',
    name: '',
    iban: '',
    bankIdentifierCode: '',
    address: '',
    bankName: '',
    bankAddress: '',
    bankCountry: '',
  });

  console.log(formData);

  // ON-CHANGE FUNCTION FOR CUSTOM-TEXTINPUT
  const handleChangeInput = (value: string, fieldName: string) => {
    setFormData({...formData, [fieldName]: value});
  };

  const onClickHandler = async () => {
    const data = {
      profileId: '108666483065290764',
      sourceInstrument: {
        type: 'managed_accounts',
        id: '108804117507801100',
      },
      transferAmount: {
        currency: 'EUR',
        amount: formData?.amount,
      },
      tag: 'tag',
      description: 'wired transfer',
      destinationBeneficiary: {
        name: formData?.name,
        bankAccountDetails: {
          iban: formData?.iban,
          bankIdentifierCode: formData?.bankIdentifierCode,
        },
        address: formData?.address,
        bankName: formData?.bankName,
        bankAddress: formData?.bankAddress,
        bankCountry: formData?.bankCountry,
      },
    };

    const response = await fetch(
      `${server_url}/multi/outgoing_wire_transfers`,
      {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'idempotency-ref': 'ref_3896',
          'Content-Type': 'application/json',
          Authorization: `Bearer ${corporate_token}`,
          'api-key': api_key,
        },
        body: JSON.stringify(data),
      },
    );

    console.log(response);
  };

  return (
    <SafeAreaView style={mainStyle}>
      <ScrollView>
        <View style={{flex: 1}}>
          <View>
            <BankingHeader headText="Bank transfer" />
          </View>
          <View style={[styles.bankingTabs, Shadow]}>
            <BankingTabs selected={selected} setSelected={setSelected} />
          </View>

          <View style={{flex: 1, backgroundColor: 'lightgray'}}>
            <CustomTextInput
              fieldName="amount"
              label="Amount"
              keyboardType="number-pad"
              handleChangeInput={handleChangeInput}
              screen="Wire Transfer"
            />
            <CustomTextInput
              fieldName="name"
              label="Name"
              handleChangeInput={handleChangeInput}
              screen="Wire Transfer"
            />
            <CustomTextInput
              fieldName="iban"
              label="Iban"
              handleChangeInput={handleChangeInput}
              screen="Wire Transfer"
            />
            <CustomTextInput
              fieldName="bankIdentifierCode"
              label="BankIdentifierCode"
              handleChangeInput={handleChangeInput}
              screen="Wire Transfer"
            />
            <CustomTextInput
              fieldName="address"
              label="Address"
              handleChangeInput={handleChangeInput}
              screen="Wire Transfer"
            />
            <CustomTextInput
              fieldName="bankName"
              label="Bank Name"
              handleChangeInput={handleChangeInput}
              screen="Wire Transfer"
            />
            <CustomTextInput
              fieldName="bankAddress"
              label="Bank Address"
              handleChangeInput={handleChangeInput}
              screen="Wire Transfer"
            />
            <CustomTextInput
              fieldName="bankCountry"
              label="Bank Country"
              handleChangeInput={handleChangeInput}
              screen="Wire Transfer"
            />
            <View style={{marginTop: 20}}>
              <CustomButton
                buttonText="Transfer"
                pressed={pressed}
                onPress={onClickHandler}
              />
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default BankTransfer;

let deviceWidth = Dimensions.get('screen').width;
const styles = StyleSheet.create({
  bankingTabs: {
    margin: 20,
  },
});

{
  /* <View>
          {selected === 0 ? (
            <View>
              <Individuals
                visible={visible}
                HandleVisibility={setVisible}
                currencyType={currencyType}
                setCurrencyType={setCurrencyType}
              />
            </View>
          ) : null}
        </View> */
}
{
  /* <View
          style={{
            position: 'absolute',
            height: Dimensions.get('screen').height,
            width: Dimensions.get('screen').width,
          }}>
          <CurrencyModal
            visible={visible}
            HandleVisibility={setVisible}
            currencyType={currencyType}
            setCurrencyType={setCurrencyType}
          />
        </View> */
}
