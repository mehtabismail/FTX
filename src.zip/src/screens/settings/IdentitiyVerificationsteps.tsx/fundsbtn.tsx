import {StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React from 'react';
import ArrowDown from '../../../assets/authenticationScreen/greaterthan.svg';
import Colors from '../../../theme/Colors';

const Fundsbtn = (props: any) => {
  console.log(props, '======');
  return (
    <View style={{paddingVertical: 10}}>
      <TouchableOpacity
        onPress={() => {
          props?.onClick(props?.BtnText);
        }}
        style={{
          borderColor:
            props?.BtnText === props?.selected ? Colors.Primary : '#DCDCDC',
          borderRadius: 5,
          borderWidth: 2,
          padding: 10,
          display: 'flex',
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}>
        <Text
          style={{
            fontFamily: 'RedHatDisplay-SemiBold',
            letterSpacing: 0.3,
            color:
              props?.BtnText === props?.selected ? Colors.Primary : '#A2A2A2',
          }}>
          {props?.BtnText}
        </Text>
        <View>
          <ArrowDown height={15} width={15} />
        </View>
      </TouchableOpacity>
    </View>
  );
};

export default Fundsbtn;

const styles = StyleSheet.create({});
