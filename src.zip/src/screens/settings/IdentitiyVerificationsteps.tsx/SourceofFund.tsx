import {Alert, SafeAreaView, StyleSheet, Text, View} from 'react-native';
import React, {useState} from 'react';
import FundsBtn from './fundsbtn';
import ContinueBtn from './ContinueBtn';
import {useNavigation} from '@react-navigation/native';
import navigationStrings from '../../../constants/navigationStrings';

const SourceofFund = () => {
  const [selected, setSelected] = useState('');
  const navigation: any = useNavigation();
  const clickHandler = () => {
    !!selected &&
      navigation.navigate(navigationStrings.VERIFYIDENTITYSTEP2, {selected});
    !!selected === false && Alert.alert('Select one option!');
  };
  const onPressHandler = (props: any) => {
    console.log(props);
    setSelected(props);
  };
  return (
    <SafeAreaView>
      <View
        style={{
          width: '90%',
          alignSelf: 'center',
          padding: 20,
          marginVertical: 40,
          backgroundColor: '#ffff',
          shadowColor: '#000000',
          shadowOpacity: 0.1,
          shadowRadius: 2,
          shadowOffset: {
            height: 1,
            width: 1,
          },
        }}>
        <Text
          style={{
            paddingBottom: 20,
            fontFamily: 'RedHatDisplay-Bold',
            color: 'black',
          }}>
          Source of your funds
        </Text>
        <Text>Select where your funds comes from</Text>
        <View>
          <FundsBtn
            BtnText="Occupation"
            selected={selected}
            onClick={onPressHandler}
          />
        </View>
        <View>
          <FundsBtn
            BtnText="Investment"
            selected={selected}
            onClick={onPressHandler}
          />
        </View>
        <View>
          <FundsBtn
            BtnText="Inheritance"
            selected={selected}
            onClick={onPressHandler}
          />
        </View>
        <View>
          <FundsBtn
            BtnText="Mining"
            selected={selected}
            onClick={onPressHandler}
          />
        </View>
        <View>
          <FundsBtn
            BtnText="Others"
            selected={selected}
            onClick={onPressHandler}
          />
        </View>
        <View>
          <ContinueBtn BtnText="Continue" clickHandler={clickHandler} />
        </View>
      </View>
    </SafeAreaView>
  );
};

export default SourceofFund;

const styles = StyleSheet.create({});
