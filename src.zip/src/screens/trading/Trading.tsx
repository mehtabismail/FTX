import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Trading = () => {
  return (
    <View>
      <Text>Trading Screen</Text>
    </View>
  )
}

export default Trading

const styles = StyleSheet.create({})