// import { store } from "../redux/Store";
// const state = store.getState();
export const configData: any = {
  corporate_token:
    'eyJhbGciOiJIUzI1NiJ9.eyJTWVNURU0iOiJmYWxzZSIsInN1YiI6IlVTRVIsMTA4NjcyMjU5Njc1MTI3ODIwIiwiTUFYX0ZBQ1RPUl9MRVZFTCI6IjAiLCJSQU5ET00iOiIzNDI4NTU3NjQ1ODM3ODk3NjUyIiwiRkFDVE9SX0xFVkVMIjoiMCIsIklERU5USVRZX0lEIjoiMTA4NjY3OTIyMTg5ODQ0NDkyIiwiSURFTlRJVFlfVFlQRSI6ImNvcnBvcmF0ZXMiLCJQRVJQRVRVQUwiOiJmYWxzZSIsIlRFTkFOVF9JRCI6IjEyNzgiLCJJTVBFUlNPTkFUT1JfU0VTU0lPTl9JRCI6IjAiLCJTRVNTSU9OX0lEIjoiMTA4OTYzNjY5OTA4MTI3NzUzIiwiUFJPR1JBTU1FX0lEIjoiMTA4NjY2NDgyOTgwNDg3MTgwIiwiSU1QRVJTT05BVEVEIjoiZmFsc2UiLCJBVVRIX0dST1VQX0lEIjoiIn0.0k4a6W9IF6Qv8AQjg4f8YA6Y3lRxDZHo9K-sWW2HXdQ',
  server_url: 'https://sandbox.weavr.io/',
  api_key: 'NNYH23wbRVEBgg+XLT8BDA==',
  verificationCode: 123456,
  managed_cards_profile_id: '108666483020529676',
  // managed_card_id:'108798097197301772',
  managed_card_formData: {
    blockedMerchantCategories: ['7995'],
    blockedMerchantIds: [],
    allowedMerchantCategories: [],
    allowedMerchantIds: [],
    spendLimit: [],
    allowAtm: false,
    allowContactless: false,
    allowECommerce: false,
    allowCashback: false,
    allowCreditAuthorisations: false,
  },
};
