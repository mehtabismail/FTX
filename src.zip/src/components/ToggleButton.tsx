import {StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React, {useEffect, useState} from 'react';
import Colors from '../theme/Colors';
import {Shadow} from './styles/ScreenStyle';
import {
  useManagedCardRulesQuery,
  useManagedCardSpendRulesMutation,
} from '../redux/services/banking/cardDetails';
import {configData} from '../config/config';
import { useSelector } from 'react-redux';
import { RootState } from '../redux/Store';

const ToggleButton = (props: any) => {
  const {
    corporate_token,
    server_url,
    api_key,
    managed_card_formData,
  } = configData;
  const [toggle, setToggle] = useState(props?.toggle);
  const [count, setCount] = useState(0);
  const [formData, setFormData] = useState(managed_card_formData);

  const getManagedCardSpendRules = useManagedCardRulesQuery<any>();

  const {card_id}: any = useSelector(
    (state: RootState) => state?.userBankDetails?.userDetails?.Bank,
  );

  

  const [managedcardSpendRules, managedcardSpendRulesInfo] =
    useManagedCardSpendRulesMutation();

  const updateCardRules = async () => {
    if (props?.heading === 'Online transactions:') {
      setFormData({...formData, allowECommerce: !toggle});
    }
    if (props?.heading === 'Contacless payments') {
      setFormData({...formData, allowContactless: !toggle});
    }
    if (props?.heading === 'ATM withdrawals') {
      setFormData({...formData, allowAtm: !toggle});
    }
    console.log(toggle, '--------toggleButton----------', props?.heading);
    console.log(formData);
    console.log(count, '---------counter--------------');
    setCount(count + 1);
    const result = await managedcardSpendRules({formData, card_id});
    console.log(result, '-----------update cards rules-----------');
  };

  useEffect(() => {
    updateCardRules();
  }, [toggle]);

  return (
    <TouchableOpacity
      onPress={() => {
        setToggle(!toggle);
        props.onPress(toggle);
      }}
      style={[styles.mainContainer, Shadow]}>
      {toggle === false && (
        <View
          style={{...styles.rounded, ...styles.roundedContainerLeft}}></View>
      )}
      {toggle === true && (
        <View
          style={{
            ...styles.rounded,
            marginRight: 4,
            ...styles.roundedContainerRight,
          }}></View>
      )}
    </TouchableOpacity>
  );
};

export default ToggleButton;

const styles = StyleSheet.create({
  mainContainer: {
    width: 40,
    height: 22,
    borderRadius: 100,
    backgroundColor: Colors.cardBackground,
    flexDirection: 'row',
  },
  rounded: {height: 14, width: 14, borderRadius: 14 / 2, marginTop: 4},
  roundedContainerLeft: {
    marginLeft: 4,
    backgroundColor: Colors.Secondary,
    opacity: 0.2,
  },
  roundedContainerRight: {
    backgroundColor: Colors.Primary,
    marginLeft: 22,
  },
});
