import Colors from "../../theme/Colors";
import metrics from "../../theme/Metrics";

export const textInputFieldNameContainer: object = {
    width: '90%',
    alignSelf: 'center',
    marginTop:metrics.regularMargin
};


export const textInputFieldNameText: object = {
   
};

