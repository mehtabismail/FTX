import {StyleSheet, Text, View} from 'react-native';
import React from 'react';
import Colors from '../theme/Colors';
import Fonts from '../theme/Fonts';
import metrics from '../theme/Metrics';
import Graph from '../assets/bottomTabNavigation/wallet/Graph.svg';

const CustomGraphCard = (props: any) => {
  return (
    <View>
      <View style={styles.cardContainer}>
        <View style={styles.innerContainer}>
          <View>
            <Text style={styles.totalSpend}>Total Spend</Text>
          </View>
          <View style={styles.amountContainer}>
            <Text style={styles.amount}>{`$${props.amount}`}</Text>
            <Text style={styles.profitLoss}>{`${props.profitLoss}%`}</Text>
          </View>
          <View style={styles.GraphAndText}>
            <Graph />
            <View style={styles.graphAmount}>
              <Text></Text>
              <Text style={{color: Colors.textColor}}>$1.41k</Text>
              <Text style={{color: Colors.textColor}}>$800</Text>
            </View>
          </View>
          <View style={styles.actualForcast}>
            <View>
              <Text style={styles.actualForcastText}>Actual spend</Text>
              <Text
                style={{
                  ...styles.actualForcastText,
                  color: Colors.Primary,
                  marginTop: metrics.smallMargin,
                }}>{`\u2022 $${props.amount}`}</Text>
            </View>
            <View style={{marginLeft: metrics.baseMargin}}>
              <Text style={styles.actualForcastText}>ForCast spend</Text>
              <Text
                style={{
                  ...styles.actualForcastText,
                  color: Colors.textColor,
                  marginTop: metrics.smallMargin,
                }}>{`\u2022 $210.51`}</Text>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
};

export default CustomGraphCard;

const styles = StyleSheet.create({
  innerContainer: {
    margin: 20,
  },
  cardContainer: {
    backgroundColor: Colors.cardBackground,
    width: 335,
    borderRadius: 20,
    marginLeft: 20,
  },
  amountContainer: {flexDirection: 'row', marginVertical: metrics.baseMargin},
  amount: {
    fontSize: Fonts.size.input,
    fontFamily: 'RedHatDisplay-Bold',
    color: Colors.textColor,
  },
  totalSpend: {
    fontSize: Fonts.size.medium,
    fontFamily: 'RedHatDisplay-Medium',
    color: Colors.textColor,
  },
  profitLoss: {
    fontSize: Fonts.size.large,
    fontFamily: "RedHatDisplay-SemiBold",
    color: 'green',
    marginLeft: metrics.baseMargin,
  },
  GraphAndText: {
    flexDirection: 'row',
  },
  graphAmount: {
    justifyContent: 'space-between',
    marginLeft: metrics.regularMargin,
  },
  actualForcast: {flexDirection: 'row', marginVertical: metrics.baseMargin},
  actualForcastText: {
    fontSize: Fonts.size.small,
    fontFamily: 'RedHatDisplay-Medium',
    color: Colors.textColor,
  },
});
